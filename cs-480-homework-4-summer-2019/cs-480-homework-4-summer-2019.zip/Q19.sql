Select count(BookDetails.OnHold)
From BookDetails
Where BookDetails.OnHold = 'Yes';