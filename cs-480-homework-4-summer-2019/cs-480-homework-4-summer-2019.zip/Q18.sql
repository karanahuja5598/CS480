Select count(BookDetails.Available)
From BookDetails
Where BookDetails.Available = 'Yes';