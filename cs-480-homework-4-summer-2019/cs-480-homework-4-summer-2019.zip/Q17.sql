Select count(BookDetails.ONHOLD)
From BookDetails
Where BookDetails.Title = 'Little Red Riding Hood' AND BookDetails.ONHOLD = 'Yes';