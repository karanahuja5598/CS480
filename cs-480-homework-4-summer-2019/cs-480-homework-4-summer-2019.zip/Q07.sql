INSERT INTO Books(BOOKID,TITLE,AUTHOR,NUMBEROFCOPIES,GENRE) VALUES (6,'Anne of Green Gables','Lucy Maud Montgomery',2,'Novel');

INSERT INTO BookDetails(BOOKID,TITLE,AUTHOR,LOCATION,AVAILABLE,ISDAMAGED,BOOKBARCODE,ONHOLD,CUSTOMERID) VALUES 
(6,'Anne of Green Gables','Lucy Maud Montgomery','Washington','Yes','No',567,'No',0),
(7,'Anne of Green Gables','Lucy Maud Montgomery','Washington','Yes','No',567,'No',0);