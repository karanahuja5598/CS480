Select BooksByMonth.Month,BooksByMonth.HowManyOut,BooksByMonth.WhichYear
From BooksByMonth
Where BooksByMonth.WhichYear = 2018;