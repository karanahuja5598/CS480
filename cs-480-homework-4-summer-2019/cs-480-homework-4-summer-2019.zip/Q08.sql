INSERT INTO Customer(ID,CHECK_OUT,CHECK_IN,PUT_HOLD,CANCEL_HOLD,NAME) VALUES (6,'No','No','No','No','Anne Shirley'),
(7,'No','No','No','No','Gilbert Blythe');