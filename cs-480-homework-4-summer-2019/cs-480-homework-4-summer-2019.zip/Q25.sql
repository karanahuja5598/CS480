Delete from BookDetails Where BookDetails.Location = 'Grand Library at Alexandria';
Delete from Books Where Books.BOOKID = 4;