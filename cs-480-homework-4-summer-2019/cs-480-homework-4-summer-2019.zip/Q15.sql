Select WorkShifts.StaffID
From WorkShifts
Where WorkShifts.WILLWORK = '12/11/2018'
ORDER BY WorkShifts.STAFFID ASC;