SELECT Customer.ID
FROM Customer
WHERE Customer.Name = 'Samwise Gamgee'
ORDER BY Customer.Name ASC;