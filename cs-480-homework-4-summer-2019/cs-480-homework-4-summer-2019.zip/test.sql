show databases;
use mysql;
select * from user;
