SELECT Books.Title
FROM Books
WHERE Books.Author = 'J.K. Rowling'
ORDER BY Books.Author ASC;