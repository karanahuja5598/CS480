Select WorkShifts.StaffID
From WorkShifts
Where WorkShifts.WORKEDON = '08/01/2018'
ORDER BY WorkShifts.STAFFID ASC;