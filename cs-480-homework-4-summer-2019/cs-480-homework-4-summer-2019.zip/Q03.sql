SELECT BookDetails.Location
FROM BookDetails
WHERE BookDetails.Title = 'A Song of Ice and Fire'
ORDER BY BookDetails.Location ASC;