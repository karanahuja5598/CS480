DELIMITER //

DROP TRIGGER IF EXISTS MinStockAmountInsert;
CREATE TRIGGER MinStockAmountInsert BEFORE INSERT ON Stock
FOR EACH ROW
IF NEW.Quantity <= 0 THEN 
  SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Stock Quantity must be greater than 0'; 
END IF;
//

DROP TRIGGER IF EXISTS MinStockAmountUpdate;
CREATE TRIGGER MinStockAmountUpdate BEFORE UPDATE ON Stock
FOR EACH ROW
IF NEW.Quantity <= 0 THEN 
  SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Stock Quantity must be greater than 0'; 
END IF;
//

DROP TRIGGER IF EXISTS MinAccountBalanceInsert;
CREATE TRIGGER MinAccountBalanceInsert BEFORE INSERT ON Person
FOR EACH ROW
IF NEW.Balance <= 0 THEN 
  SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Account Balance must be greater than 0'; 
END IF;
//

DROP TRIGGER IF EXISTS MinAccountBalanceUpdate;
CREATE TRIGGER MinAccountBalanceUpdate BEFORE UPDATE ON Person
FOR EACH ROW
IF NEW.Balance <= 0 THEN 
  SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Account Balance must be greater than 0'; 
END IF;
//

DROP TRIGGER IF EXISTS MinOrderPriceInsert;
CREATE TRIGGER MinOrderPriceInsert BEFORE INSERT ON SellOrder
FOR EACH ROW
IF NEW.Price < 0.05 THEN 
  SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Minimum transaction price of 0.05'; 
END IF;
//

DROP TRIGGER IF EXISTS MinOrderPriceUpdate;
CREATE TRIGGER MinOrderPriceUpdate BEFORE UPDATE ON SellOrder
FOR EACH ROW
IF NEW.Price < 0.05 THEN 
  SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Minimum transaction price of 0.05'; 
END IF;
//

DELIMITER ;