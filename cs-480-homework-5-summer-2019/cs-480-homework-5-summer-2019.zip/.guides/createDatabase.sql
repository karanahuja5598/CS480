DROP DATABASE IF EXISTS StockMarket;
CREATE DATABASE StockMarket;
USE StockMarket;


DROP TABLE IF EXISTS `Company`;
CREATE TABLE `Company` (
  `CompanyID` int(11) DEFAULT NULL AUTO_INCREMENT,
  `CompanyName` varchar(60) DEFAULT NULL,
  `TickerName` varchar(4) NOT NULL UNIQUE,
  PRIMARY KEY (`CompanyID`)
);

DROP TABLE IF EXISTS `Person`;
CREATE TABLE `Person` (
  `AccountID` int(11) NOT NULL AUTO_INCREMENT,
  `Balance` decimal(14,2) DEFAULT NULL,
  `AccountName` varchar(60) DEFAULT NULL,
  PRIMARY KEY (`AccountID`)
);

DROP TABLE IF EXISTS `Stock`;
CREATE TABLE `Stock` (
  `StockID` int(11) NOT NULL AUTO_INCREMENT,
  `CompanyID` int(11) NOT NULL,
  `AccountID` int(11) NOT NULL,
  `Quantity` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`StockID`),
  FOREIGN KEY (`CompanyID`) REFERENCES `Company` (`CompanyID`)
  ON DELETE CASCADE,
  FOREIGN KEY (`AccountID`) REFERENCES `Person` (`AccountID`)
  ON DELETE CASCADE
) ;

DROP TABLE IF EXISTS `SellOrder`;
CREATE TABLE `SellOrder` (
  `LotID` int(11) NOT NULL AUTO_INCREMENT,
  `StockID` int(11) NOT NULL UNIQUE,
  `Price` decimal(6,2) DEFAULT 1,
  PRIMARY KEY (`LotID`),
  FOREIGN KEY (`StockID`) REFERENCES `Stock` (`StockID`)
  ON DELETE CASCADE
);

INSERT INTO `Company` VALUES (123,'C','C'),(456,'D','D'),(789,'E','E');
INSERT INTO `Person` VALUES (11,4616.00,'A'),(22,900807.00,'B');
INSERT INTO `Stock` VALUES (10,123,11,10),(20,456,22,5),(30,123,22,100),(40,789,22,100),(50,789,22,50),(60,456,22,15);
INSERT INTO `SellOrder` VALUES (1,10,10.23),(2,20,50),(4,40,25.56),(5,50,25.55),(6,60,50);

-- INSERT INTO `Company` VALUES (1,'A','A'),(2,'B','B'),(3,'C','C'),(4,'D','D'),(5,'E','E'),(6,'F','F'),(7,'G','G'),(8,'H','H'),(9,'I','I'),(10,'J','J'),(11,'K','K'),(12,'L','L'),(13,'M','M'),(14,'N','N'),(15,'O','O'),(16,'P','P'),(17,'Q','Q'),(18,'R','R'),(19,'S','S'),(20,'T','T'),(21,'U','U'),(22,'V','V'),(23,'W','W'),(24,'X','X'),(25,'Y','Y'),(26,'Z','Z'),(1001,'Alphabet','GOOG'),(55,'Oracle','ORCL'),(124,'Caterpillar','CAT'),(125,'Dow 30','DOG');
-- INSERT INTO `Person` VALUES (1,15216.00,'Alice'),(2,6727.00,'Bob'),(3,11270.00,'Carol'),(4,10000.00,'Dave'),(5,5000.00,'Eve'),(46,10.00,'Frank'),(17,310.00,'Abe'),(28,9000.00,'Mc\'Donald'),(9,9000.00,'MacGregor'),(10,20.00,'O\'Leery'),(11,9000.00,'Soverign'),(12,20.00,'Emilio'),(14,0.00,'L\'Chuck'),(15,0.00,'Nyx');
-- INSERT INTO `Stock` VALUES (1,1001,5,10),(3,3,1,100),(4,3,3,100),(5,3,3,100),(6,3,2,100),(7,3,1,90),(8,55,5,100),(9,3,2,100),(10,3,1,100),(11,5,1,100),(12,6,2,1000),(13,7,3,1500),(14,8,4,250),(17,3,5,10),(18,3,17,100),(20,1,9,20),(21,1,1,48),(22,1,1,10),(23,1,1,10),(24,1,1,10),(25,1,2,1),(26,1,2,1),(27,125,46,1000),(28,124,15,1000),(29,1001,15,5);
-- INSERT INTO `SellOrder` VALUES (1,1,10.23),(2,6,32.56),(5,13,2500.00),(7,18,0.45),(8,14,19.00);
