SOURCE ~/workspace/.guides/createDatabase.sql;
SOURCE ~/workspace/buildFunctions.sql;
SOURCE ~/workspace/buildTriggers.sql;
SELECT * FROM Person WHERE AccountNAME IN ('A','B');
SELECT * FROM Stock WHERE AccountID IN (11,22);
SELECT * FROM SellOrder;
CALL SellStock('A', 'C', 5, 15.00);
CALL SellStock('B', 'E', 60, 1.00);
CALL SellStock('B', 'E', 100, 12.00);
CALL SellStock('B', 'C', 1, 0.02);
CALL SellStock('B', 'C', 1, 0.50);
SELECT * FROM Person WHERE AccountNAME IN ('A','B');
SELECT * FROM Stock WHERE AccountID IN (11,22);
SELECT * FROM SellOrder;

