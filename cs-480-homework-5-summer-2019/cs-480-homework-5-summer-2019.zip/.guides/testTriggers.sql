SOURCE ~/workspace/.guides/createDatabase.sql;
SOURCE ~/workspace/buildTriggers.sql;

SELECT * FROM Stock;
INSERT INTO Stock(CompanyID, AccountID, Quantity) VALUES(123,11,-1);
INSERT INTO Stock(CompanyID, AccountID, Quantity) VALUES(456,11,0);
INSERT INTO Stock(CompanyID, AccountID, Quantity) VALUES(789,22,50);
UPDATE Stock SET Quantity = 100 WHERE StockID = 20;
SELECT * FROM Stock WHERE StockID = 20;
UPDATE Stock SET Quantity = -100 WHERE StockID = 20;
SELECT * FROM Stock;

SELECT * FROM Person;
INSERT INTO Person(AccountName, Balance) VALUES('Negative Ned', -50);
INSERT INTO Person(AccountName, Balance) VALUES('Zeroed out Zach', 0);
INSERT INTO Person(AccountName, Balance) VALUES('Positive Pete', 100);
UPDATE Person SET Balance = 100 WHERE AccountID = 11;
SELECT * FROM Person WHERE AccountID = 1;
UPDATE Person SET Balance = -100 WHERE AccountID = 11;
SELECT * FROM Person;

SELECT * FROM SellOrder;
INSERT INTO SellOrder(StockID, Price) VALUES(10,-5.00);
INSERT INTO SellOrder(StockID, Price) VALUES(20,0.00);
INSERT INTO SellOrder(StockID, Price) VALUES(30,0.4);
INSERT INTO SellOrder(StockID, Price) VALUES(40,0.45);
INSERT INTO SellOrder(StockID, Price) VALUES(50,0.5);
UPDATE SellOrder SET Price = -5.00 WHERE LotID = 1;
UPDATE SellOrder SET Price = 0.00 WHERE LotID = 2;
-- UPDATE SellOrder SET Price = 0.40 WHERE LotID = 4;
UPDATE SellOrder SET Price = 0.45 WHERE LotID = 4;
UPDATE SellOrder SET Price = 0.50 WHERE LotID = 5;
SELECT * FROM SellOrder;




-- 
-- 
-- SOURCE ~/workspace/.guides/createDatabase.sql;
-- SOURCE ~/workspace/buildTriggers.sql;

-- SELECT * FROM Stock;
-- INSERT INTO Stock(CompanyID, AccountID, Quantity) VALUES(1,1,-1);
-- INSERT INTO Stock(CompanyID, AccountID, Quantity) VALUES(3,4,0);
-- INSERT INTO Stock(CompanyID, AccountID, Quantity) VALUES(2,5,50);
-- UPDATE Stock SET Quantity = 100 WHERE StockID = 4;
-- SELECT * FROM Stock WHERE StockID = 4;
-- UPDATE Stock SET Quantity = -100 WHERE StockID = 4;
-- SELECT * FROM Stock;

-- SELECT * FROM Person;
-- INSERT INTO Person(AccountName, Balance) VALUES('Negative Ned', -50);
-- INSERT INTO Person(AccountName, Balance) VALUES('Zeroed out Zach', 0);
-- INSERT INTO Person(AccountName, Balance) VALUES('Positive Pete', 100);
-- UPDATE Person SET Balance = 100 WHERE AccountID = 1;
-- SELECT * FROM Person WHERE AccountID = 1;
-- UPDATE Person SET Balance = -100 WHERE AccountID = 1;
-- SELECT * FROM Person;

-- SELECT * FROM SellOrder;
-- INSERT INTO SellOrder(StockID, Price) VALUES(3,-5.00);
-- INSERT INTO SellOrder(StockID, Price) VALUES(4,0.00);
-- INSERT INTO SellOrder(StockID, Price) VALUES(5,0.4);
-- INSERT INTO SellOrder(StockID, Price) VALUES(9,0.45);
-- INSERT INTO SellOrder(StockID, Price) VALUES(7,0.5);
-- UPDATE SellOrder SET Price = -5.00 WHERE LotID = 1;
-- UPDATE SellOrder SET Price = 0.00 WHERE LotID = 2;
-- UPDATE SellOrder SET Price = 0.40 WHERE LotID = 5;
-- UPDATE SellOrder SET Price = 0.45 WHERE LotID = 7;
-- UPDATE SellOrder SET Price = 0.50 WHERE LotID = 8;
-- SELECT * FROM SellOrder;


-- INSERT INTO `Company` VALUES (1,'A','A'),(2,'B','B'),(3,'C','C'),(1001,'Alphabet','GOOG'),(55,'Oracle','ORCL'),(124,'Caterpillar','CAT'),(125,'Dow 30','DOG');
-- INSERT INTO `Person` VALUES (1,15216.00,'Alice'),(2,6727.00,'Bob'),(3,11270.00,'Carol'),(4,10000.00,'Dave'),(5,5000.00,'Eve'),(46,10.00,'Frank'),(17,310.00,'Abe'),(28,9000.00,'Mc\'Donald'),(9,9000.00,'MacGregor'),(10,20.00,'O\'Leery'),(11,9000.00,'Soverign'),(12,20.00,'Emilio'),(14,0.00,'L\'Chuck'),(15,0.00,'Nyx');
-- INSERT INTO `Stock` VALUES (1,1001,5,10),(3,3,2,100),(4,3,2,100),(5,3,3,100),(6,3,3,100),(7,3,1,90),(8,55,4,100),(9,3,2,100),(10,3,1,100),(11,55,1,100),(12,124,2,1000),(13,125,3,1500),(27,125,46,1000),(28,124,15,1000),(29,1001,15,5);
-- INSERT INTO `SellOrder` VALUES (1,1,10.23),(2,5,32.56),(5,13,2500.00),(7,27,0.45),(8,29,19.00);


-- INSERT INTO `Company` VALUES (123,'C','C'),(456,'D','D'),(789,'E','E');
-- INSERT INTO `Person` VALUES (11,46016.00,'A'),(22,900807.00,'B');
-- INSERT INTO `Stock` VALUES (10,123,11,10),(20,456,22,100),(30,123,22,100),(40,789,22,100),(50,789,22,50);
-- INSERT INTO `SellOrder` VALUES (1,10,10.23),(2,20,32.56),(4,40,2500.56),(5,50,2500.55);


