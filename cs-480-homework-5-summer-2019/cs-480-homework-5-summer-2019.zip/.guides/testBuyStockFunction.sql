SOURCE ~/workspace/.guides/createDatabase.sql;
SOURCE ~/workspace/buildFunctions.sql;
SOURCE ~/workspace/buildTriggers.sql;
SELECT * FROM Person WHERE AccountNAME IN ('A','B');
SELECT * FROM Stock WHERE AccountID IN (11,22);
SELECT * FROM SellOrder;
SELECT BuyStock('A', 'E', 1);
SELECT BuyStock('A', 'E', 60);
SELECT BuyStock('A', 'E', 92);
SELECT BuyStock('A', 'E', 89);
SELECT BuyStock('A', 'C', 1);
SELECT BuyStock('A', 'D', 20);
SELECT * FROM Person WHERE AccountNAME IN ('A','B');
SELECT * FROM Stock WHERE AccountID IN (11,22);
SELECT * FROM SellOrder;


-- SOURCE ~/workspace/.guides/createDatabase.sql;
-- SOURCE ~/workspace/buildFunctions.sql;
-- SOURCE ~/workspace/buildTriggers.sql;
-- SELECT * FROM Person WHERE AccountNAME IN ('Bob','Dave','Nyx');
-- SELECT * FROM Stock WHERE AccountID IN (2,4,15);
-- SELECT * FROM SellOrder;
-- SELECT BuyStock('Dave', 'C', 1);
-- SELECT BuyStock('Dave', 'C', 200);
-- SELECT BuyStock('Dave', 'C', 199);
-- SELECT BuyStock('Nyx', 'Alphabet', 1);
-- SELECT * FROM Person WHERE AccountNAME IN ('Bob','Dave','Nyx');
-- SELECT * FROM Stock WHERE AccountID IN (2,4,15);
-- SELECT * FROM SellOrder;





