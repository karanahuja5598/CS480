DROP PROCEDURE IF EXISTS BuyStock;
DELIMITER //

CREATE PROCEDURE BuyStock ( IN PNAME VARCHAR(20), IN SNAME VARCHAR(20), in amount int)
BEGIN
DECLARE TotalPrice DECIMAL(10,4) DEFAULT 0.00;

DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
    ROLLBACK;
    RESIGNAL;
    END;
    
START TRANSACTION;

SELECT CompanyID into @CID FROM Company WHERE CompanyName = SNAME;
SELECT AccountID into @PID FROM Person WHERE AccountName = PNAME;


WHILE amount > 0 DO
BEGIN
    SELECT Quantity, LotID, StockID, AccountID, Price, COUNT(*) into @QF, @LID, @SID, @OID, @Price, @nrows
    FROM Stock NATURAL JOIN SellOrder
    WHERE CompanyID = @CID AND AccountID<>@PID
    LIMIT 1;
    IF @nrows=0 THEN SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Insufficient quantity of stock available for purchase'; 
        ROLLBACK;
    END IF;

   -- SELECT @QF,@LID,amount;

    IF (@QF>amount) THEN
        BEGIN
        INSERT INTO Stock(CompanyID, AccountID, Quantity) VALUES(@CID, @PID, amount);
        UPDATE Stock SET Quantity = @QF - amount WHERE StockID = @SID;
        UPDATE Person SET Balance = Balance - @Price*amount WHERE AccountID = @PID;
        UPDATE Person SET Balance = Balance + @Price*amount WHERE AccountID = @OID;
        SET TotalPrice = TotalPrice + @Price*amount;
        SET amount = 0;
        END;
    ELSE
        BEGIN
        DELETE FROM SellOrder WHERE LotID = @LID;
        UPDATE Stock SET AccountID = @PID WHERE StockID = @SID;
        UPDATE Person SET Balance = Balance - @Price*@QF WHERE AccountID = @PID;
        UPDATE Person SET Balance = Balance + @Price*@QF WHERE AccountID = @OID;
        SET amount = amount-@QF;
        SET TotalPrice = TotalPrice + @Price*@QF;
        END;
    END IF;
    IF amount = 0 then SELECT TotalPrice; COMMIT; END IF;
END;
END WHILE;
    
END;
//
DELIMITER ;









































DROP PROCEDURE IF EXISTS SellStock;
DELIMITER //

CREATE PROCEDURE SellStock ( IN PNAME VARCHAR(20), IN SNAME VARCHAR(20), in amount int, in price decimal(8,2))
BEGIN
DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
    ROLLBACK;
    RESIGNAL;
    END;
    
START TRANSACTION;

SELECT CompanyID into @CID FROM Company WHERE CompanyName = SNAME;
SELECT AccountID into @PID FROM Person WHERE AccountName = PNAME;


WHILE amount > 0 DO
BEGIN
    SELECT Quantity, Stock.StockID, AccountID, COUNT(*) into @QF, @SID, @OID, @nrows
    FROM Stock LEFT OUTER JOIN SellOrder
    ON Stock.StockID = SellOrder.StockID
    WHERE CompanyID = @CID AND AccountID=@PID AND LotID IS NULL
    LIMIT 1;
    IF @nrows=0 THEN SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Insufficient quantity of stock available to sell'; 
        ROLLBACK;
    END IF;

  --  SELECT @QF,@LID,amount;

    IF (@QF>amount) THEN
        BEGIN
        INSERT INTO Stock(CompanyID, AccountID, Quantity) VALUES(@CID, @PID, amount);
        INSERT INTO SellOrder(StockID, Price) VALUES (LAST_INSERT_ID(), price);
        UPDATE Stock SET Quantity = @QF - amount WHERE StockID = @SID;
        SET amount = 0;
        END;
    ELSE
        BEGIN
        INSERT INTO SellOrder(StockID, Price) VALUES (@SID, price);
        SET amount = amount-@QF;
        END;
    END IF;
    IF amount = 0 then COMMIT; END IF;
END;
END WHILE;
    
END;
//
DELIMITER ;

















































DROP PROCEDURE IF EXISTS DepositFunds;
CREATE PROCEDURE DepositFunds ( IN PNAME VARCHAR(20), in amount decimal(8,2))
UPDATE Person SET Balance = Balance + amount WHERE AccountName = PNAME;

DROP PROCEDURE IF EXISTS WithdrawFunds;
CREATE PROCEDURE WithdrawFunds ( IN PNAME VARCHAR(20), in amount decimal(8,2))
UPDATE Person SET Balance = Balance - amount WHERE AccountName = PNAME;

